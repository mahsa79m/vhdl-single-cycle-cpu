library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity RegisterFile_tb is
end RegisterFile_tb;

architecture behavior of RegisterFile_tb is 
    -- Component Signals
    signal clk      : std_logic := '0';
    signal rst      : std_logic := '0';
    signal regWrite : std_logic := '0';
    signal readReg1 : std_logic_vector(4 downto 0) := (others => '0');
    signal readReg2 : std_logic_vector(4 downto 0) := (others => '0');
    signal writeReg : std_logic_vector(4 downto 0) := (others => '0');
    signal writeData: std_logic_vector(31 downto 0) := (others => '0');
    signal readData1: std_logic_vector(31 downto 0);
    signal readData2: std_logic_vector(31 downto 0);

    -- Clock period definition
    constant clk_period : time := 10 ns;

begin
    -- Instantiate the Unit Under Test (UUT)
    uut: entity work.RegisterFile PORT MAP (
          clk => clk,
          rst => rst,
          regWrite => regWrite,
          readReg1 => readReg1,
          readReg2 => readReg2,
          writeReg => writeReg,
          writeData => writeData,
          readData1 => readData1,
          readData2 => readData2
        );

    -- Clock process definitions
    clk_process :process
    begin
        clk <= '0';
        wait for clk_period/2;
        clk <= '1';
        wait for clk_period/2;
    end process;

    -- Stimulus process
    stim_proc: process
    begin		
        -- Step 1: Reset the system
        rst <= '1';
        wait for 20 ns;	
        rst <= '0';
        wait for clk_period;

        -- Step 2: Write 0xAAAA5555 into Register 5
        regWrite <= '1';
        writeReg <= "00101"; -- Register 5
        writeData <= x"AAAA5555";
        wait for clk_period;

        -- Step 3: Write 0x12345678 into Register 10
        writeReg <= "01010"; -- Register 10
        writeData <= x"12345678";
        wait for clk_period;

        -- Step 4: Disable writing and read back both registers
        regWrite <= '0';
        readReg1 <= "00101"; -- Should show AAAA5555
        readReg2 <= "01010"; -- Should show 12345678
        wait for 20 ns;

        -- Step 5: Try to write to Register 0 (Should remain 0)
        regWrite <= '1';
        writeReg <= "00000"; 
        writeData <= x"FFFFFFFF";
        wait for clk_period;
        
        regWrite <= '0';
        readReg1 <= "00000"; -- Should still be 0
        
        wait;
    end process;
end behavior;