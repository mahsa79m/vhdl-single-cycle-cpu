
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ALU is
    Port (
        A          : in  STD_LOGIC_VECTOR (31 downto 0);
        B          : in  STD_LOGIC_VECTOR (31 downto 0);
        ALUControl : in  STD_LOGIC_VECTOR (2 downto 0);
        Result     : out STD_LOGIC_VECTOR (31 downto 0);
        Zero       : out STD_LOGIC
    );
end ALU;

architecture Behavioral of ALU is
    signal res_internal : UNSIGNED(31 downto 0);
begin
    process(A, B, ALUControl)
    begin
        case ALUControl is
            when "000" => -- AND
                res_internal <= UNSIGNED(A) and UNSIGNED(B);
            when "001" => -- OR
                res_internal <= UNSIGNED(A) or UNSIGNED(B);
            when "010" => -- ADD
                res_internal <= UNSIGNED(A) + UNSIGNED(B);
            when "110" => -- SUB
                res_internal <= UNSIGNED(A) - UNSIGNED(B);
            when "111" => -- SLT
                if (UNSIGNED(A) < UNSIGNED(B)) then
                    res_internal <= x"00000001";
                else
                    res_internal <= x"00000000";
                end if;
            when others =>
                res_internal <= (others => '0');
        end case;
    end process;

    Result <= STD_LOGIC_VECTOR(res_internal);
    Zero <= '1' when res_internal = x"00000000" else '0';

end Behavioral;