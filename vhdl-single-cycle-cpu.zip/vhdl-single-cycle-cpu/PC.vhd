library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity PC is
    Port (
        clk       : in  STD_LOGIC;
        rst       : in  STD_LOGIC;
        address_in: in  STD_LOGIC_VECTOR (31 downto 0);
        address_out: out STD_LOGIC_VECTOR (31 downto 0)
    );
end PC;

architecture Behavioral of PC is
begin
    process(clk, rst)
    begin
        if rst = '1' then
            -- Starting address (usually 0)
            address_out <= (others => '0');
        elsif rising_edge(clk) then
            -- Update PC with the next address
            address_out <= address_in;
        end if;
    end process;
end Behavioral;