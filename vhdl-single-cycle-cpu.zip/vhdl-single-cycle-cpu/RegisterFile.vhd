library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity RegisterFile is
    Port (
        clk      : in  STD_LOGIC;
        rst      : in  STD_LOGIC;
        regWrite : in  STD_LOGIC; -- Control signal to enable writing
        readReg1 : in  STD_LOGIC_VECTOR (4 downto 0); -- Address of RS
        readReg2 : in  STD_LOGIC_VECTOR (4 downto 0); -- Address of RT
        writeReg : in  STD_LOGIC_VECTOR (4 downto 0); -- Address of RD
        writeData: in  STD_LOGIC_VECTOR (31 downto 0); -- Data to be written
        readData1: out STD_LOGIC_VECTOR (31 downto 0); -- Output RS
        readData2: out STD_LOGIC_VECTOR (31 downto 0)  -- Output RT
    );
end RegisterFile;

architecture Behavioral of RegisterFile is
    -- Create an array of 32 registers, each 32-bit wide
    type reg_array is array (0 to 31) of STD_LOGIC_VECTOR(31 downto 0);
    --signal registers : reg_array := (others => (others => '0'));
	 signal registers : reg_array := (
    1 => x"0000000A", --10
    2 => x"00000005", --5
    others => (others => '0')
);
begin

    -- Synchronous Write Process
    process(clk, rst)
    begin
        if rst = '1' then
            -- Optional: Reset all registers to 0
            registers <= (others => (others => '0'));
        elsif rising_edge(clk) then
            if regWrite = '1' then
                -- Register 0 is usually hardwired to 0 in many architectures
                if to_integer(unsigned(writeReg)) /= 0 then
                    registers(to_integer(unsigned(writeReg))) <= writeData;
                end if;
            end if;
        end if;
    end process;

    -- Asynchronous Read
    readData1 <= registers(to_integer(unsigned(readReg1)));
    readData2 <= registers(to_integer(unsigned(readReg2)));

end Behavioral;