library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ControlUnit_tb is
end ControlUnit_tb;

architecture behavior of ControlUnit_tb is 
    signal Opcode : std_logic_vector(5 downto 0) := (others => '0');
    -- Outputs
    signal RegDst, ALUSrc, MemtoReg, RegWrite, MemRead, MemWrite, Branch : std_logic;
    signal ALUOp : std_logic_vector(1 downto 0);
begin
    uut: entity work.ControlUnit PORT MAP (
          Opcode => Opcode,
          RegDst => RegDst, ALUSrc => ALUSrc, MemtoReg => MemtoReg,
          RegWrite => RegWrite, MemRead => MemRead, MemWrite => MemWrite,
          Branch => Branch, ALUOp => ALUOp
        );

    stim_proc: process
    begin		
        -- Test R-type (e.g. ADD)
        Opcode <= "000000"; wait for 20 ns;
        -- Test LW
        Opcode <= "100011"; wait for 20 ns;
        -- Test BEQ
        Opcode <= "000100"; wait for 20 ns;
        wait;
    end process;
end behavior;