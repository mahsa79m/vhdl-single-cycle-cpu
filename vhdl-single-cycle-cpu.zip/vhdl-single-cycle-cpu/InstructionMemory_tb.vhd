library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity InstructionMemory_tb is
end InstructionMemory_tb;

architecture behavior of InstructionMemory_tb is 
    -- Signals
    signal Address     : std_logic_vector(31 downto 0) := (others => '0');
    signal Instruction : std_logic_vector(31 downto 0);

begin
    -- Instantiate the Unit Under Test (UUT)
    uut: entity work.InstructionMemory PORT MAP (
          Address => Address,
          Instruction => Instruction
        );

    -- Stimulus process
    stim_proc: process
    begin		
        -- Test Address 0
        Address <= x"00000000";
        wait for 20 ns;	

        -- Test Address 4 (Next Instruction)
        Address <= x"00000004";
        wait for 20 ns;

        -- Test Address 8
        Address <= x"00000008";
        wait for 20 ns;

        -- Test Address 12
        Address <= x"0000000C";
        wait for 20 ns;

        wait;
    end process;
end behavior;