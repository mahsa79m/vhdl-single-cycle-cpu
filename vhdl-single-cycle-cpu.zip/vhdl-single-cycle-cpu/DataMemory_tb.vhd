library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity DataMemory_tb is
end DataMemory_tb;

architecture behavior of DataMemory_tb is 
    -- Signals
    signal clk       : std_logic := '0';
    signal memWrite  : std_logic := '0';
    signal memRead   : std_logic := '0';
    signal address   : std_logic_vector(31 downto 0) := (others => '0');
    signal writeData : std_logic_vector(31 downto 0) := (others => '0');
    signal readData  : std_logic_vector(31 downto 0);

    constant clk_period : time := 10 ns;

begin
    -- Instantiate UUT
    uut: entity work.DataMemory PORT MAP (
          clk => clk,
          memWrite => memWrite,
          memRead => memRead,
          address => address,
          writeData => writeData,
          readData => readData
        );

    -- Clock process
    clk_process :process
    begin
        clk <= '0';
        wait for clk_period/2;
        clk <= '1';
        wait for clk_period/2;
    end process;

    -- Stimulus process
    stim_proc: process
    begin		
        -- Step 1: Write data 0xDEADBEEF to address 4
        memWrite <= '1';
        address <= x"00000004";
        writeData <= x"DEADBEEF";
        wait for clk_period;

        -- Step 2: Write data 0x12345678 to address 8
        address <= x"00000008";
        writeData <= x"12345678";
        wait for clk_period;

        -- Step 3: Read back from address 4
        memWrite <= '0';
        memRead <= '1';
        address <= x"00000004";
        wait for clk_period;

        -- Step 4: Read back from address 8
        address <= x"00000008";
        wait for clk_period;

        -- Step 5: Try to read address 12 (should be 0)
        address <= x"0000000C";
        wait for clk_period;

        wait;
    end process;
end behavior;