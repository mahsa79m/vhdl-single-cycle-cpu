library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity DataMemory is
    Port (
        clk      : in  STD_LOGIC;
        memWrite : in  STD_LOGIC;
        memRead  : in  STD_LOGIC;
        address  : in  STD_LOGIC_VECTOR (31 downto 0);
        writeData: in  STD_LOGIC_VECTOR (31 downto 0);
        readData : out STD_LOGIC_VECTOR (31 downto 0)
    );
end DataMemory;

architecture Behavioral of DataMemory is
    type ram_type is array (0 to 63) of STD_LOGIC_VECTOR(31 downto 0);
    signal RAM : ram_type := (others => (others => '0'));
begin
    process(clk)
    begin
        if rising_edge(clk) then
            if memWrite = '1' then
                RAM(to_integer(unsigned(address(7 downto 2)))) <= writeData;
            end if;
        end if;
    end process;

    readData <= RAM(to_integer(unsigned(address(7 downto 2)))) when memRead = '1' else (others => '0');
end Behavioral;