library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity SingleCycleCPU_tb is
end SingleCycleCPU_tb;

architecture behavior of SingleCycleCPU_tb is 
    -- Inputs
    signal clk : std_logic := '0';
    signal rst : std_logic := '0';

    -- Clock period definitions
    constant clk_period : time := 10 ns;

begin
    -- Instantiate the Unit Under Test (UUT)
    uut: entity work.SingleCycleCPU PORT MAP (
          clk => clk,
          rst => rst
        );

    -- Clock process definitions
    clk_process :process
    begin
        clk <= '0';
        wait for clk_period/2;
        clk <= '1';
        wait for clk_period/2;
    end process;

    -- Stimulus process
    stim_proc: process
    begin		
        -- Step 1: Reset the CPU
        rst <= '1';
        wait for 20 ns;	
        rst <= '0';

        -- Step 2: Let the CPU run for several cycles
        -- It will execute instructions from InstructionMemory automatically
        wait for 200 ns;

        wait;
    end process;
end behavior;