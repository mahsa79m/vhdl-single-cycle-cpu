library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ALU_tb is
end ALU_tb;

architecture behavior of ALU_tb is 
    signal A          : std_logic_vector(31 downto 0) := (others => '0');
    signal B          : std_logic_vector(31 downto 0) := (others => '0');
    signal ALUControl : std_logic_vector(2 downto 0) := (others => '0');
    signal Result     : std_logic_vector(31 downto 0);
    signal Zero       : std_logic;
begin
    uut: entity work.ALU PORT MAP (
          A => A,
          B => B,
          ALUControl => ALUControl,
          Result => Result,
          Zero => Zero
        );




	stim_proc: process
    begin		
        -- Test Case 1: ADD (10 + 5 = 15)
        A <= std_logic_vector(to_unsigned(10, 32));
        B <= std_logic_vector(to_unsigned(5, 32));
        ALUControl <= "010"; 
        wait for 20 ns;
        
        -- Test Case 2: SUB (20 - 8 = 12)
        A <= std_logic_vector(to_unsigned(20, 32));
        B <= std_logic_vector(to_unsigned(8, 32));
        ALUControl <= "110";
        wait for 20 ns;

        -- Test Case 3: AND (Binary: 1100 AND 1010 = 1000)
        A <= x"0000000C"; -- 12 in decimal
        B <= x"0000000A"; -- 10 in decimal
        ALUControl <= "000"; 
        wait for 20 ns;

        -- Test Case 4: OR (Binary: 1100 OR 1010 = 1110)
        A <= x"0000000C"; -- 12 in decimal
        B <= x"0000000A"; -- 10 in decimal
        ALUControl <= "001"; 
        wait for 20 ns;

        -- Test Case 5: BEQ logic (15 - 15 = 0, Zero=1)
        A <= std_logic_vector(to_unsigned(15, 32));
        B <= std_logic_vector(to_unsigned(15, 32));
        ALUControl <= "110";
        wait for 20 ns;

        wait;
    end process;
	 
end behavior;