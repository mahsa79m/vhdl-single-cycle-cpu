library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity SingleCycleCPU is
    Port (
        clk : in  STD_LOGIC;
        rst : in  STD_LOGIC
    );
end SingleCycleCPU;

architecture Structural of SingleCycleCPU is
    -- Internal Signals for Interconnection
    signal pc_current, pc_next : std_logic_vector(31 downto 0);
    signal instr : std_logic_vector(31 downto 0);
    signal reg_dst, alu_src, mem_to_reg, reg_write, mem_read, mem_write, branch : std_logic;
    signal alu_op : std_logic_vector(1 downto 0);
    signal write_reg : std_logic_vector(4 downto 0);
    signal write_data, read_data1, read_data2 : std_logic_vector(31 downto 0);
    signal imm_ext : std_logic_vector(31 downto 0);
    signal alu_in2 : std_logic_vector(31 downto 0);
    signal alu_result : std_logic_vector(31 downto 0);
    signal alu_zero : std_logic;
    signal alu_ctrl : std_logic_vector(2 downto 0);
    signal mem_read_data : std_logic_vector(31 downto 0);

begin
    -- 1. Program Counter
    PC_Unit: entity work.PC port map(clk, rst, pc_next, pc_current);

    -- 2. Instruction Memory
    IMEM: entity work.InstructionMemory port map(pc_current, instr);

    -- 3. Control Unit
    CU: entity work.ControlUnit port map(instr(31 downto 26), reg_dst, alu_src, mem_to_reg, reg_write, mem_read, mem_write, branch, alu_op);

    -- 4. Register File
    write_reg <= instr(20 downto 16) when reg_dst = '0' else instr(15 downto 11);
    RF: entity work.RegisterFile port map(clk, rst, reg_write, instr(25 downto 21), instr(20 downto 16), write_reg, write_data, read_data1, read_data2);

    -- 5. Sign Extend (Immediate value)
    imm_ext <= std_logic_vector(resize(signed(instr(15 downto 0)), 32));

    -- 6. ALU Control
    alu_ctrl <= "010" when alu_op = "00" else -- ADD for LW/SW
                "110" when alu_op = "01" else -- SUB for BEQ
                "010" when alu_op = "10" and instr(5 downto 0) = "100000" else -- ADD
                "110" when alu_op = "10" and instr(5 downto 0) = "100010" else -- SUB
                "000"; -- Default AND

    -- 7. ALU
    alu_in2 <= read_data2 when alu_src = '0' else imm_ext;
    ALU_Unit: entity work.ALU port map(read_data1, alu_in2, alu_ctrl, alu_result, alu_zero);

    -- 8. Data Memory
    DMEM: entity work.DataMemory port map(clk, mem_write, mem_read, alu_result, read_data2, mem_read_data);

    -- 9. Writeback Logic
    write_data <= alu_result when mem_to_reg = '0' else mem_read_data;

    -- 10. Next PC Logic (Simple PC + 4)
    pc_next <= std_logic_vector(unsigned(pc_current) + 4);

end Structural;