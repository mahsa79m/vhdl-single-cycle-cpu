library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity InstructionMemory is
    Port (
        Address : in  STD_LOGIC_VECTOR (31 downto 0);
        Instruction : out STD_LOGIC_VECTOR (31 downto 0)
    );
end InstructionMemory;

architecture Behavioral of InstructionMemory is
    type rom_type is array (0 to 31) of STD_LOGIC_VECTOR(31 downto 0);
    -- Sample Instructions (In Hex):
    signal ROM : rom_type := (
        0 => x"00221820", -- ADD
        --1 => x"00852822", -- SUB
		  1 => x"00222022",
        --2 => x"8C010000", -- LW
		  2 => x"AC030008",
        --3 => x"AC020004", -- SW
		  3 => x"8C050008",
        others => (others => '0')
    );
begin
    -- In single cycle, we divide address by 4 or just use it as index
    Instruction <= ROM(to_integer(unsigned(Address(6 downto 2))));
end Behavioral;